require("GenomicRanges") || stop("unable to load GenomicRanges package")
GenomicRanges:::.test()
